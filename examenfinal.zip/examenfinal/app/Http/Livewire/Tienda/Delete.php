<?php

namespace App\Http\Livewire\Tienda;
use App\Models\Tienda;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class Delete extends Component
{
    public tienda $tienda;
    public $foto;
    public function render()
    {
        return view('livewire.tienda.delete');
    }

    public function delete()
    {
        if ($this->tienda->foto != null) {
            Storage::disk("public")->delete("/Tienda", $this->foto);
        }
        $this->tienda->delete();
        return redirect(route("tienda.index"));
    }


}
