<?php

namespace App\Http\Livewire\Tienda;

use Livewire\Component;

class Rules extends Component
{
    public static function Reglas()
    {
        return[
            'tienda.foto'=>'nullable|image',
            'tienda.color'=>'required|string',
            'tienda.precio'=>'required|integer'
        ];
    }
}
