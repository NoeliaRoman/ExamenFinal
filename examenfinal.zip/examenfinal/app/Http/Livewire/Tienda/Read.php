<?php

namespace App\Http\Livewire\Tienda;

use Livewire\Component;

class Read extends Component
{
    public function render()
    {
        return view('livewire.tienda.read');
    }
}
