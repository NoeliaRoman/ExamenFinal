<?php

namespace App\Http\Livewire\Tienda;

use App\Http\Livewire\Tienda\Rules;
use App\Models\Tienda;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class Create extends Component

{
    use WithFileUploads;
    public tienda $tienda;
    public $foto;


    public function mount()
    {
        $this->tienda = new tienda();
    }

    public function render()
    {
        return view('livewire.tienda.create');
    }

    public function crear()
    {
        $this->validate();
        if($this->foto!=null){
            $this->tienda->foto = Storage::disk('public')->put('Tienda', $this->foto);

        }

        $this->tienda->save();
        return redirect(route('tienda.index'));
    }

    protected function rules()
    {
        return Rules::Reglas();
    }
}
