<?php

namespace App\Http\Livewire\Tienda;
use App\Models\Tienda;

use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;


class Update extends Component
{
    use WithFileUploads;
    public Tienda $tienda;
    public $foto;


    public function render()
    {
        return view('livewire.tienda.update');
    }
    public function edit(){
        $this->validate();
        if($this->foto!=null){
            if($this->tienda->foto!=null){
                Storage::disk('public')->delete($this->tienda->foto);
            }
            $this->tienda->foto = Storage::disk('public')->put('Tienda', $this->foto);
        }
        $this->tienda->save();
        return redirect(route('tienda.index'));

    }
    public function Rules(){
        return[
            'tienda.foto'=>'nullable|image',
            'tienda.color'=>'required|string',
            'tienda.precio'=>'required|integer'
        ];
    }
}
