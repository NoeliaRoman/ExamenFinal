<?php

namespace App\Http\Livewire\Tienda;

use Livewire\Component;
use App\Models\tienda;
use Livewire\WithPagination;

class Index extends Component
{
    protected $paginationTheme = 'bootstrap';
    use WithPagination;
    public $search;
    public $cargado = false;


    public function render()
    {
        $tiendas = Tienda::all();
        return view('livewire.tienda.index', compact('tiendas'));
    }

    public function  updatingSearch(){
        $this->resetPage();
    }

    public function cargando(){

    }
}

?>
