<?php

namespace App\Http\Livewire\Users;
use App\Models\User;
use Livewire\Component;

class UsersRead extends Component
{
    public user $user;
    public function render()
    {
        return view('livewire.users.users-read');
    }
}
