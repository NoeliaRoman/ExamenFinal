<?php

namespace App\Http\Livewire\Users;
use App\Models\User;
use Livewire\Component;

class UsersIndex extends Component
{


    public function render()
    {
        $users = User::all();
        //dd($users);
        return view('livewire.users.users-index', compact('users'));
    }
}
