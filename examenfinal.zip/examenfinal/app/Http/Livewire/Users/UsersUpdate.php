<?php

namespace App\Http\Livewire\Users;
use App\Models\User;
use Livewire\Component;

class UsersUpdate extends Component
{
    public user $user;
    public function render()
    {
        return view('livewire.users.users-update');
    }

    public function editar(){
        $this->validate();
        $this->user->save();
        return redirect(route('users.index'));



    }

    public function Rules(){
        return UsersRules::Rules($this->user->id);
    }
}
