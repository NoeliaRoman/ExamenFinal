<?php

namespace App\Http\Livewire\Users;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Hash;
use App\Http\Livewire\Users\UsersRules;
use App\Models\User;
use Livewire\Component;

class UsersCreate extends Component
{
    public User $users;
    public $password;
    
    public function mount(){
    $this->users = new User();
    }
    public function render()
    {
        return view('livewire.users.users-create');
    }

    public function create(){
        $this->validate();
        $this->users->save();

    //  $this->user->password = Hash::make($this->user->password);
        return redirect(route('users.index'));
    }

    public function rules(){
        return UsersRules::Rules();
    }

}




