<?php

namespace App\Http\Livewire\Users;

use Livewire\Component;

class UsersRules
{
    public static function Rules($id=null)
    {
        //$validarpassword = ($id) ? 'nullable|min:8' : 'required|min:8';
        return[
            'users.name'=>'required|string',
            'users.email'=>'required|email|unique:users,email,' .$id,
            'users.password'=>'nullable|string',
            
        ];

    }

}
