<?php return array (
  'login.login' => 'App\\Http\\Livewire\\Login\\Login',
  'tienda.create' => 'App\\Http\\Livewire\\Tienda\\Create',
  'tienda.delete' => 'App\\Http\\Livewire\\Tienda\\Delete',
  'tienda.index' => 'App\\Http\\Livewire\\Tienda\\Index',
  'tienda.read' => 'App\\Http\\Livewire\\Tienda\\Read',
  'tienda.rules' => 'App\\Http\\Livewire\\Tienda\\Rules',
  'tienda.update' => 'App\\Http\\Livewire\\Tienda\\Update',
  'users.users-create' => 'App\\Http\\Livewire\\Users\\UsersCreate',
  'users.users-delete' => 'App\\Http\\Livewire\\Users\\UsersDelete',
  'users.users-index' => 'App\\Http\\Livewire\\Users\\UsersIndex',
  'users.users-read' => 'App\\Http\\Livewire\\Users\\UsersRead',
  'users.users-update' => 'App\\Http\\Livewire\\Users\\UsersUpdate',
);