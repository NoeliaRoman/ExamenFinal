<?php

use App\Http\Livewire\Users\UsersCreate;
use App\Http\Livewire\Users\UsersRead;
use App\Http\Livewire\Users\UsersUpdate;
use App\Http\Livewire\Users\UsersDelete;

use App\Http\Livewire\Tienda\Create;
use App\Http\Livewire\Tienda\Delete;
use App\Http\Livewire\Tienda\Index;
use App\Http\Livewire\Tienda\Update;

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Login\Login;
use App\Http\Livewire\Users\UsersIndex;

Route::get('/login', Login::class)->name('login');

Route::group(["middlerare" => "auth"], function(){
    Route::get('users/create', UsersCreate::class)->name('users.create');
    Route::get('users/read', UsersRead::class)->name('users.read');
    Route::get('users/update', UsersUpdate::class)->name('users.update');
    Route::get('users/delete', UsersDelete::class)->name('users.delete');
    Route::get('users/index', UsersIndex::class)->name('users.index');

    Route::get('tienda/create', Create::class)->name('tienda.create');
    Route::get('tienda/update', Update::class)->name('tienda.update');
    Route::get('tienda/delete', Delete::class)->name('tienda.delete');
    Route::get('tienda/index', Index::class)->name('tienda.index');

});

