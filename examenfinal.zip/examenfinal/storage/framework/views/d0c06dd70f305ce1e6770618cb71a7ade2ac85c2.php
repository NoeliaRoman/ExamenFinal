<div>
    <form wire:submit.prevent="edit">
        <div class="card">
            <div class="card-header">
                Modificar mercancia
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.tienda.formularioEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button wire:loading.attr="disabled" wire:target="foto" class="btn btn-success btn-sm"><i class="fa fa-iedit"></i> Modificar</button>
                <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/tienda/update.blade.php ENDPATH**/ ?>