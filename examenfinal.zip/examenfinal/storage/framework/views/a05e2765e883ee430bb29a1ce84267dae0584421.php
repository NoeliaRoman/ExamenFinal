

<div>
    <div class="mx-auto card" style="width: 18rem;">
        <div class="card-body">
            <div class="card-title">
                <h2>Eliminar usuario</h2>
            </div>
            <?php if($foto != null): ?>
                <img style="width:230px;height:230px;" src="<?php echo e($foto->temporaryUrl()); ?>" alt="">
            <?php else: ?>
                <img style="border-radius:230px; width:230px;height:230px;"
                src="<?php echo e(Storage::disk("public")->url($tienda->foto ? $tienda->foto : "Tienda/default.png")); ?>" alt="">
            <?php endif; ?>
            <h5 class="card-title"><?php echo e($tienda->color); ?></h5>
            <p class="card-text"><?php echo e($tienda->precio); ?></p>
            <button wire:click="delete" class="btn btn-danger btn-sm">Eliminar</button>
            <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial3\examenfinal\resources\views/livewire/tienda/delete.blade.php ENDPATH**/ ?>