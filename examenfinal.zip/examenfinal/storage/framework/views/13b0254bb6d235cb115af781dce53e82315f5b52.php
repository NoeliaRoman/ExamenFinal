<div>
    <form wire:submit.prevent="crear">
        <div class="card">
            <div class="card-header">
                Subir mercancia
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.tienda.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button wire:loading.attr="disabled" wire:target="foto" class="btn btn-success btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/tienda/create.blade.php ENDPATH**/ ?>