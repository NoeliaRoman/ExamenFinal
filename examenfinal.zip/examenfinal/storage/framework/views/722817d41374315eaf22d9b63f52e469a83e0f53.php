<div class="row">


    <div class="mx-auto col-6">
        <div class="form-group">
            <label>Nombre de Usuario</label>
            <input wire:model="users.name" type="text" class="form-control">
            <?php $__errorArgs = ['users.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input wire:model.defer="users.email" type="email" class="form-control">
            <?php $__errorArgs = ['users.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        <div class="form-group">
            <label>Contrasena</label>
            <input autocomplete="new-password" wire:model.defer="password" type="password" class="form-control">
            <?php $__errorArgs = ['users.password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>



    </div>

</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/Users/formulario.blade.php ENDPATH**/ ?>