<div>
    <div class="mx-auto card" style="width: 18rem;">
        <div class="card-body">
        <h5 class="card-title">Desea eliminarlo?<h5>
          <p class="card-text"><?php echo e($tienda->color); ?></p>
          <p class="card-text"><?php echo e($tienda->precio); ?></p>
          <button wire:click="delete" class="btn btn-primary btn-sm">Confirmar</button>
          <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
      </div>
</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/tienda/delete.blade.php ENDPATH**/ ?>