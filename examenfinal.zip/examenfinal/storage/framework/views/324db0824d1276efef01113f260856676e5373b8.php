<form wire:submit.prevent="create">

<div class="row">
    <div wire:loading wire:target="foto" class=" align-items-center">

    <strong>Loading...</strong>
    <div class="spinner-border ms-auto" role="status" aria-hidden="true"></div>
    </div>
    <div class="col-4">

        <?php if( $foto!= null): ?>
        <img  style = "width: 130px; height : 130px", src="<?php echo e($foto->temporaryURL()); ?>">

         <?php else: ?>
         <img  style = "width: 130px; height : 130px", src="<?php echo e(Storage::disk('public')->url($tienda->foto!=null ? $tienda->foto : 'tienda/default.png')); ?>">

        <?php endif; ?>

        <form>
            <div class="form-group">
              <label for="exampleFormControlFile1">Subir Imagen</label>
              <input  wire:model="foto"type="file" class="form-control-file" id="exampleFormControlFile1">
              <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </form>
    </div>


    <div class="mx-auto col-6">
        <div class="form-group">
            <label>Color</label>
            <input wire:model.defer="tienda.color" type="text" class="form-control">
            <?php $__errorArgs = ['tienda.color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>Precio</label>
            <input wire:model.defer="tienda.precio" type="text" class="form-control">
            <?php $__errorArgs = ['tienda.precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
</div>
</form>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial3\examenfinal\resources\views/livewire/tienda/formulario.blade.php ENDPATH**/ ?>