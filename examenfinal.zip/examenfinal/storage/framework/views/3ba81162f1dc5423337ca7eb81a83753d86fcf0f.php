<div>
<?php if(count($users) > 0): ?>
    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th scope="col">Nombre</th>
                <th scope="col">E-mail</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.index', $user)); ?>"title="Mostrar mas" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('users.update', $user)); ?>" title="Editar usuario" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(route('users.delete', $user)); ?>" title="Eliminar usuario seleccionado más" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial3\examenfinal\resources\views/livewire/users/users-index.blade.php ENDPATH**/ ?>