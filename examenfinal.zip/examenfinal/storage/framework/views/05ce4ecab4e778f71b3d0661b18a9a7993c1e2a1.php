<div>
    <form wire:submit.prevent="editar">
        <div class="card">
            <div class="card-header">
                Modificar Usuario
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.users.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button wire:loading.attr="disabled" wire:target="foto" class="btn btn-primary btn-sm">
                    <i class="fa fa-edit"></i> Modificar</button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial3\examenfinal\resources\views/livewire/users/users-update.blade.php ENDPATH**/ ?>