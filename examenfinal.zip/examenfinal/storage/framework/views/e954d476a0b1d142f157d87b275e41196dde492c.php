<div>

    <div class="row">
        <div class="mx-auto col-md-4">

            <form wire:submit.prevent="login">
                <div class="mb-3">
                  <label  class="form-label">Correo Electronico</label>
                  <input  wire:model="email" type="email" class="form-control"  placeholder="ejemplo@email.com">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><b class="text-danger"><?php echo e($message); ?></b><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="mb-3">
                  <label  class="form-label">Contraseña</label>
                  <input wire:model="password" placeholder="*********" type="password" class="form-control" >
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><b class="text-danger"><?php echo e($message); ?></b><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 form-check">
                  <input type="checkbox" class="form-check-input" >
                  <label class="form-check-label" for="exampleCheck1">Recuerdame</label>
                </div>
                <button type="submit" class="btn btn-primary">Iniciar Session</button>
              </form>
        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/login/login.blade.php ENDPATH**/ ?>