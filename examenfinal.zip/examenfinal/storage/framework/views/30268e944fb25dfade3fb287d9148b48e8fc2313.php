<div wire:init="cargando">

    <div class="row">
        <div class="col-md-4 ">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1"><i class="fa fe-search"></i></span>
                <input wire:model="search" type="search" class="form-control" placeholder="Buscar..." aria-label="Username" aria-describedby="basic-addon1">
            </div>

        </div>


    </div>

<?php if((count($tiendas)) > 0): ?>



    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th>Imagen</th>
                <th scope="col">Color</th>
                <th scope="col">Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>
                        <img style= "width: 240px ; height:240px;"src="<?php echo e(Storage::disk('public')->url($tienda->foto!=null ? $tienda->foto : 'Tienda/default.png' )); ?>">
                    </th>
                    <td><?php echo e($tienda->color); ?></td>
                    <td><?php echo e($tienda->precio); ?></td>
                    <td>
                        <a href="<?php echo e(route('tienda.index', $tienda)); ?>"title="Mostrar mas" class="btn-sm" style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('tienda.update', $tienda)); ?>" title="Editar tienda"
                            class="btn-sm " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(route('tienda.delete', $tienda)); ?>" title="Eliminar tienda seleccionado más"
                            class="btn-sm" style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>

<?php else: ?>
<img class="mx-auto d-block" style="width: 300px; height:300px;" src="<?php echo e(Storage::disk('public')->url('otros/loading.gif')); ?>" alt="">
<?php endif; ?>
    <?php echo e($cargado == true ? $tiendas->links() : null); ?>


</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial3\examenfinal\resources\views/livewire/tienda/index.blade.php ENDPATH**/ ?>