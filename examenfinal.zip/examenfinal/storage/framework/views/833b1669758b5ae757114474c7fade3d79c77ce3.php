<div>
    <form wire:submit.prevent="create">
        <div class="card">
            <div class="card-header">
                Crear usuario
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.users.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button wire:loading.attr="disabled"  class="btn btn-success btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
<?php /**PATH C:\xampp\htdocs\examenfinal\resources\views/livewire/users/users-create.blade.php ENDPATH**/ ?>