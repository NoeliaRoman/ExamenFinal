

<div>
    <div class="mx-auto card" style="width: 18rem;">
        <div class="card-body">
            <div class="card-title">
                <h2>Eliminar objeto</h2>
            </div>
            @if ($foto != null)
                <img style="width:230px;height:230px;" src="{{ $foto->temporaryUrl() }}" alt="">
            @else
                <img style="border-radius:230px; width:230px;height:230px;"
                src="{{ Storage::disk("public")->url($tienda->foto ? $tienda->foto : "Tienda/default.png") }}" alt="">
            @endif
            <h5 class="card-title">{{$tienda->color}}</h5>
            <p class="card-text">{{$tienda->precio}}</p>
            <button wire:click="delete" class="btn btn-danger btn-sm">Eliminar</button>
            <a href="{{route('tienda.index')}}" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
    </div>
</div>
