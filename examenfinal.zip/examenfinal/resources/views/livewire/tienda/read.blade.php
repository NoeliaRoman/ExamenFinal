<div>
    <div class="card mx-auto" style="width: 18rem;">
        <div class="card-body">
          <p class="card-title">Color: {{$tienda->color}}</p>
          <p class="card-text">Precio: {{$tienda->precio}}</p>

          <a href="{{route('tienda.index')}}" class="btn btn-secondary btn-sm">Regresar</a>
        </div>
      </div>
</div>
