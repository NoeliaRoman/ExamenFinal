<div wire:init="cargando">

    <div class="row">
        <div class="col-md-4 ">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1"><i class="fa fe-search"></i></span>
                <input wire:model="search" type="search" class="form-control" placeholder="Buscar..." aria-label="Username" aria-describedby="basic-addon1">
            </div>

        </div>


    </div>

@if((count($tiendas)) > 0)



    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th>Imagen</th>
                <th scope="col">Color</th>
                <th scope="col">Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>

            @foreach ($tiendas as $tienda)
                <tr>
                    <th>
                        <img style= "width: 240px ; height:240px;"src="{{Storage::disk('public')->url($tienda->foto!=null ? $tienda->foto : 'Tienda/default.png' )}}">
                    </th>
                    <td>{{ $tienda->color }}</td>
                    <td>{{ $tienda->precio }}</td>
                    <td>
                        <a href="{{route('tienda.index', $tienda)}}"title="Mostrar mas" class="btn-sm" style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-eye"></i></a>
                        <a href="{{ route('tienda.update', $tienda) }}" title="Editar tienda"
                            class="btn-sm " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-edit"></i></a>
                        <a href="{{ route('tienda.delete', $tienda) }}" title="Eliminar tienda seleccionado más"
                            class="btn-sm" style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            @endforeach


        </tbody>
    </table>

@else
<img class="mx-auto d-block" style="width: 300px; height:300px;" src="{{Storage::disk('public')->url('otros/loading.gif')}}" alt="">
@endif
    {{ $cargado == true ? $tiendas->links() : null}}

</div>
