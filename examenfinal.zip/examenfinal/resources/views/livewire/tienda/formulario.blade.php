<form wire:submit.prevent="create">

<div class="row">
    <div wire:loading wire:target="foto" class=" align-items-center">

    <strong>Loading...</strong>
    <div class="spinner-border ms-auto" role="status" aria-hidden="true"></div>
    </div>
    <div class="col-4">

        @if ( $foto!= null)
        <img  style = "width: 130px; height : 130px", src="{{$foto->temporaryURL()}}">

         @else
         <img  style = "width: 130px; height : 130px", src="{{Storage::disk('public')->url($tienda->foto!=null ? $tienda->foto : 'tienda/default.png')  }}">

        @endif

        <form>
            <div class="form-group">
              <label for="exampleFormControlFile1">Subir Imagen</label>
              <input  wire:model="foto"type="file" class="form-control-file" id="exampleFormControlFile1">
              @error('foto') <span class="text-danger">{{ $message }}</span>@enderror
            </div>
          </form>
    </div>


    <div class="mx-auto col-6">
        <div class="form-group">
            <label>Color</label>
            <input wire:model.defer="tienda.color" type="text" class="form-control">
            @error('tienda.color') <span class="text-danger">{{ $message }}</span>@enderror
        </div>

        <div class="form-group">
            <label>Precio</label>
            <input wire:model.defer="tienda.precio" type="text" class="form-control">
            @error('tienda.precio') <span class="text-danger">{{ $message }}</span>@enderror

        </div>
    </div>
</div>
</form>
