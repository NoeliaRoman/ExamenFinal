<div>
    <form wire:submit.prevent="create">
        <div class="card">
            <div class="card-header">
                Crear usuario
            </div>
            <div class="card-body">
                @include('livewire.users.formulario')
            </div>
            <div class="card-footer text-muted">
                <button wire:loading.attr="disabled"  class="btn btn-success btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="{{ route('users.index') }}" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
