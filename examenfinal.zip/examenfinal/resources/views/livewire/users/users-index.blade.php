<div>
@if (count($users) > 0)
    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th scope="col">Nombre</th>
                <th scope="col">E-mail</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>
                        <a href="{{route('users.index', $user)}}"title="Mostrar mas" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-eye"></i></a>
                        <a href="{{ route('users.update', $user) }}" title="Editar usuario" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-edit"></i></a>
                        <a href="{{ route('users.delete', $user) }}" title="Eliminar usuario seleccionado más" class="btn-sm btn " style="background-color:#c1c7fe; color:#fff;"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    @endif
</div>
