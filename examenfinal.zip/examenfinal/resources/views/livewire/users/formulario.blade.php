<div class="row">


    <div class="mx-auto col-6">
        <div class="form-group">
            <label>Nombre de Usuario</label>
            <input wire:model="users.name" type="text" class="form-control">
            @error('users.name') <span class="text-danger">{{ $message }}</span>@enderror
        </div>

        <div class="form-group">
            <label>Email</label>
            <input wire:model.defer="users.email" type="email" class="form-control">
            @error('users.email') <span class="text-danger">{{ $message }}</span>@enderror

        </div>


        <div class="form-group">
            <label>Contrasena</label>
            <input autocomplete="new-password" wire:model.defer="users.password" type="password" class="form-control">
            @error('users.password') <span class="text-danger">{{ $message }}</span>@enderror

        </div>



    </div>

</div>
