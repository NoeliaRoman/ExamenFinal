<div>
    <div class="mx-auto card" style="width: 18rem;">
        <div class="card-body">
            <div class="card-title">
                <h2>Eliminar usuario</h2>
            </div>
            <h5 class="card-title">{{$user->nombre}}</h5>
            <p class="card-text">{{$user->email}}</p>
            <button wire:click="delete" class="btn btn-danger btn-sm">Eliminar</button>
            <a href="{{route('users.index')}}" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
    </div>
</div>
