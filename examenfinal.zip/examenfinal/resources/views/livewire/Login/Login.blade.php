<div>

    <div class="row">
        <div class="mx-auto col-md-4">

            <form wire:submit.prevent="login">
                <div class="mb-3">
                  <label  class="form-label">Correo Electronico</label>
                  <input  wire:model="email" type="email" class="form-control"  placeholder="ejemplo@email.com">
                  @error('email')<b class="text-danger">{{$message}}</b>@enderror

                </div>
                <div class="mb-3">
                  <label  class="form-label">Contraseña</label>
                  <input wire:model="password" placeholder="*********" type="password" class="form-control" >
                  @error('password')<b class="text-danger">{{$message}}</b>@enderror
                </div>
                <div class="mb-3 form-check">
                  <input type="checkbox" class="form-check-input" >
                  <label class="form-check-label" for="exampleCheck1">Recuerdame</label>
                </div>
                <button type="submit" class="btn btn-primary">Iniciar Session</button>
              </form>
        </div>

    </div>

</div>
